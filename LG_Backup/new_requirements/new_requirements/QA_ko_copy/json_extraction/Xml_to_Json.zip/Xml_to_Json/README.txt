## How to Run ##
python xml_to_json.py "\home\LGSI\Folder_name\en-us\xml\book\us_book.main.xml"

Output: consolidated.xml, manual.json, manual_final.json be stored at "\home\LGSI\Folder_name\"
consolidated.xml--> It is consolidated xml file
manual.xml--> first stage xml to json conversion(It has redundant tags and properties)
manual_final.json--> Final processed json file ( to be used by downstream tasks)
